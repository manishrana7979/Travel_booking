from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.db.models import Q
from datetime import datetime

from .models import TravelOption, Booking
from .forms import UserRegisterForm, BookingForm

# User Registration View
def register_view(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserRegisterForm()
    return render(request, 'register.html', {'form': form})

# User Login View
def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('profile')
        else:
            return render(request, 'login.html', {'error': 'Invalid credentials'})
    return render(request, 'login.html')

# User Logout View
def logout_view(request):
    logout(request)
    return redirect('login')

# User Profile View
@login_required
def profile_view(request):
    bookings = Booking.objects.filter(user=request.user).select_related('travel_option')
    return render(request, 'profile.html', {'bookings': bookings})

# Travel List with Filters
def travel_list_view(request):
    travels = TravelOption.objects.all()

    travel_type = request.GET.get('type')
    source = request.GET.get('source')
    destination = request.GET.get('destination')
    date = request.GET.get('date')

    if travel_type:
        travels = travels.filter(type=travel_type)
    if source:
        travels = travels.filter(source__icontains=source)
    if destination:
        travels = travels.filter(destination__icontains=destination)
    if date:
        try:
            date_obj = datetime.strptime(date, '%Y-%m-%d')
            travels = travels.filter(date_time__date=date_obj.date())
        except:
            pass

    return render(request, 'travel_list.html', {'travels': travels})

# Travel Booking View
@login_required
def book_travel_view(request, travel_id):
    travel = get_object_or_404(TravelOption, id=travel_id)

    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            seats = form.cleaned_data['number_of_seats']
            if seats <= travel.available_seats:
                booking = form.save(commit=False)
                booking.user = request.user
                booking.travel_option = travel
                booking.total_price = seats * travel.price
                booking.status = 'Confirmed'
                booking.booking_date = timezone.now()
                booking.save()

                travel.available_seats -= seats
                travel.save()

                return redirect('profile')
            else:
                form.add_error(None, 'Not enough seats available.')
    else:
        form = BookingForm()

    return render(request, 'book_travel.html', {'form': form, 'travel': travel})
